Study notes. Not vendor documentation and not legal advice.
